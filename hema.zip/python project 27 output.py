Python 3.12.4 (tags/v3.12.4:8e8a4ba, Jun  6 2024, 19:30:16) [MSC v.1940 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

= RESTART: C:\Users\kunda\AppData\Local\Programs\Python\Python312\python project 27.py
15
Enter the email id:yuo@
Enter your name:hema
Enter your roll_no:727
Enter the course:csit
Enter subject_name:de
Enter your rating:4
Enter the comment:avg
Enter the email id:khy@
Enter your name:uma
Enter your roll_no:788
Enter the course:civil
Enter subject_name:autocad
Enter your rating:3
Enter the comment:excellent
Enter the email id:kur@
Enter your name:sunitha
Enter your roll_no:897
Enter the course:eee
Enter subject_name:mfcs
Enter your rating:2
Enter the comment:good
Enter the email id:hur@
Enter your name:suerekha
Enter your roll_no:456
Enter the course:cse
Enter subject_name:maths
Enter your rating:5
Enter the comment:good
Enter the email id:hut@
Enter your name:varsha
Enter your roll_no:724
Enter the course:csit
Enter subject_name:chemistry
Enter your rating:3
Enter the comment:excellent
Enter the email id:kut@
Enter your name:vyshu
Enter your roll_no:456
Enter the course:cser
Enter subject_name:hindi
Enter your rating:2
Enter the comment:avg
Enter the email id:rty@
Enter your name:teja
Enter your roll_no:710
Enter the course:csit
Enter subject_name:phy
Enter your rating:4
Enter the comment:good
Enter the email id:yuor@
Enter your name:akhila
Enter your roll_no:720
Enter the course:cse
Enter subject_name:dbms
Enter your rating:3
Enter the comment:excellent
Enter the email id:ghj@
Enter your name:susmi
Enter your roll_no:728
Enter the course:aids
Enter subject_name:at
Enter your rating:5
Enter the comment:good
Enter the email id:kio@
Enter your name:raga
Enter your roll_no:718
Enter the course:mech
Enter subject_name:eng
Enter your rating:2
Enter the comment:avg
Enter the email id:bnm@
Enter your name:sravs
Enter your roll_no:716
Enter the course:eee
Enter subject_name:telugu
Enter your rating:4
Enter the comment:good
Enter the email id:tyu@
Enter your name:harini
Enter your roll_no:234
Enter the course:iot
Enter subject_name:mefa
Enter your rating:1
Enter the comment:avg
Enter the email id:sdt@
Enter your name:maari
Enter your roll_no:387
Enter the course:csds
Enter subject_name:daa
Enter your rating:4
Enter the comment:excellent
Enter the email id:yue@
Enter your name:keena
Enter your roll_no:908
Enter the course:csit
Enter subject_name:data structres
Enter your rating:2
Enter the comment:avg
Enter the email id:hjkd@
Enter your name:samosa
Enter your roll_no:450@
Enter the course:it
Enter subject_name:beee
Enter your rating:1
Enter the comment:avg
   email_id      name roll_no course    subject_name  rating    comment
0      yuo@      hema     727   csit              de       4        avg
1      khy@       uma     788  civil         autocad       3  excellent
2      kur@   sunitha     897    eee            mfcs       2       good
3      hur@  suerekha     456    cse           maths       5       good
4      hut@    varsha     724   csit       chemistry       3  excellent
5      kut@     vyshu     456   cser           hindi       2        avg
6      rty@      teja     710   csit             phy       4       good
7     yuor@    akhila     720    cse            dbms       3  excellent
8      ghj@     susmi     728   aids              at       5       good
9      kio@      raga     718   mech             eng       2        avg
10     bnm@     sravs     716    eee          telugu       4       good
11     tyu@    harini     234    iot            mefa       1        avg
12     sdt@     maari     387   csds             daa       4  excellent
13     yue@     keena     908   csit  data structres       2        avg
14    hjkd@    samosa    450@     it            beee       1        avg
hema
yuo@ hema 727 csit de 4 avg
autocad
mfcs
chemistry
hindi
dbms
eng
mefa
data structres
beee
de
maths
phy
at
telugu
daa
maths
at
9
6
