import pandas as pd
h=[]
def add_feedback(email_id,name,roll_no,course,subject_name,rating,comment):
    feedback={
        'email_id':email_id,
        'name':name,
        'roll_no':roll_no,
        'course':course,
        'subject_name':subject_name,
        'rating':rating,
        'comment':comment
    }
    h.append(feedback)
n=int(input())
for _ in range(n):
    email_id=input("Enter the email id:")
    name=input("Enter your name:")
    roll_no=input("Enter your roll_no:")
    course=input("Enter the course:")
    subject_name=input("Enter subject_name:")
    rating=int(input("Enter your rating:"))
    comment=input("Enter the comment:")
    add_feedback(email_id,name,roll_no,course,subject_name,rating,comment)  
'''for i in range(n):
    print(s[i])'''
df=pd.DataFrame(h)
print(df)
N=input()
for i in range(n):
    if h[i]['name']==N:
        print(h[i]['email_id'],h[i]['name'],h[i]['roll_no'],h[i]['course'],h[i]['subject_name'],h[i]['rating'],h[i]['comment'])
for i in range(n):
    if h[i]['rating']<=3:
        print(h[i]['subject_name'])
for i in range(n):
    if h[i]['rating']>3:
        print(h[i]['subject_name'])
for i in range(n):
    if h[i]['rating'] == 5:
        print(h[i]['subject_name'])
c1=0
for i in range(n):
    if h[i]['rating'] <= 3:
        c1+=1
print(c1)
c2=0
for i in range(n):
    if h[i]['rating'] > 3:
        c2+=1
print(c2)
